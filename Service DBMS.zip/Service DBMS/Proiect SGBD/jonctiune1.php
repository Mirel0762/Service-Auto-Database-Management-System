<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e90ff;
            color: #fff;
        }

        .container {
            max-width: 1200px;
        }

        .my-5 {
            margin-top: 3rem;
            margin-bottom: 3rem;
            
        }

        .table {
            background-color: #fff;
            border-radius: 8px;
            color: #000; /* Culoarea textului pentru tabel */
            margin: 0 auto;
        }

        .table th,
        .table td {
            padding: 10px;
        }
    </style>
</head>
<body>
<a class="btn btn-secondary" href="index.php" role="button">BACK</a>

    <div class="container my-5">
        <h1><center>JONCTIUNE</center></h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th>cui</th>
                    <th>nume</th>
                    <th>program_lucru</th>
                    <th>nr_telefon</th>
                    <th>id_adresa</th>
                    <th>nunar</th>
                    <th>judet</th>
                    <th>localitate</th>
                    <th>strada</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "service_auto_sgbd";

                // Create connection
                $connection = mysqli_connect($servername, $username, $password, $database);

                // Check connection
                if (!$connection) {
                    die("Connection failed");
                }

                // Read all rows from the database table
                $sql = "SELECT s.cui, s.nume, s.program_lucru, s.nr_telefon, a.id_adresa, a.numar, a.judet, a.localitate, 
                a.strada FROM serviceuri s
                INNER JOIN adrese a ON s.id_adresef = a.id_adresa;
                ";
                $result = mysqli_query($connection, $sql);

                if (!$result) {
                    die("Invalid query");
                }

                // Read data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "
                    <tr>
                        <td>$row[cui]</td>  
                        <td>$row[nume]</td>  
                        <td>$row[program_lucru]</td>
                        <td>$row[nr_telefon]</td>
                        <td>$row[id_adresa]</td>
                        <td>$row[numar]</td>
                        <td>$row[judet]</td>
                        <td>$row[localitate]</td>
                        <td>$row[strada]</td>
                    </tr>  
                    ";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
