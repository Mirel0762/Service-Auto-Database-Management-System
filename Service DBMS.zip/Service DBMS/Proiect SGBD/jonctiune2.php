<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e90ff;
            color: #fff;
        }

        .container {
            max-width: 1200px;
        }

        .my-5 {
            margin-top: 3rem;
            margin-bottom: 3rem;
            
        }

        .table {
            background-color: #fff;
            border-radius: 8px;
            color: #000; /* Culoarea textului pentru tabel */
            margin: 0 auto;
        }

        .table th,
        .table td {
            padding: 10px;
        }
    </style>
</head>
<body>
<a class="btn btn-secondary" href="index.php" role="button">BACK</a>

    <div class="container my-5">
        <h1><center>JONCTIUNE</center></h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th>cod_piesa</th>
                    <th>tip</th>
                    <th>denumire</th>
                    <th>valabilitate</th>
                    <th>pret</th>
                    <th>id_operatie</th>
                    <th>cost</th>
                    <th>data_start</th>
                    <th>data_finalizare</th>
                    <th>timp_necesar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "service_auto_sgbd";

                // Create connection
                $connection = mysqli_connect($servername, $username, $password, $database);

                // Check connection
                if (!$connection) {
                    die("Connection failed");
                }

                // Read all rows from the database table
                $sql = "SELECT p.cod_piesa, p.tip, p.denumire, p.valabilitate, p.pret, o.id_operatie, o.cost, o.data_start, 
                o.data_finalizare, o.timp_necesar 
                FROM operatii o 
                LEFT JOIN piese p ON p.id_operatief = o.id_operatie;
                
                 
                ";
                $result = mysqli_query($connection, $sql);

                if (!$result) {
                    die("Invalid query");
                }

                // Read data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "
                    <tr>
                        <td>$row[cod_piesa]</td>  
                        <td>$row[tip]</td>  
                        <td>$row[denumire]</td>
                        <td>$row[valabilitate]</td>
                        <td>$row[pret]</td>
                        <td>$row[id_operatie]</td>
                        <td>$row[cost]</td>
                        <td>$row[data_start]</td>
                        <td>$row[data_finalizare]</td>
                        <td>$row[timp_necesar]</td>
                    </tr>  
                    ";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
