<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e90ff;
            color: #fff;
        }

        .container {
            max-width: 800px;
        }

        .my-5 {
            margin-top: 3rem;
            margin-bottom: 3rem;
        }

        .table {
            background-color: #fff;
            border-radius: 8px;
            color: #000; /* Culoarea textului pentru tabel */
            margin: 0 auto;
        }

        .table th,
        .table td {
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h1><center>ANGAJATI</center></h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th>cnp</th>
                    <th>nume</th>
                    <th>prenume</th>
                    <th>id_servicef</th>
                    <th></th> <!-- Coloana pentru butoane -->
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "service_auto_sgbd";

                // Create connection
                $connection = mysqli_connect($servername, $username, $password, $database);

                // Check connection
                if (!$connection) {
                    die("Connection failed");
                }

                // Handle delete action
                if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["deleteCnp"])) {
                    $deleteCnp = $_POST["deleteCnp"];
                    $deleteSql = "DELETE FROM angajati WHERE cnp = $deleteCnp";
                    mysqli_query($connection, $deleteSql);
                }

                // Handle modify action
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    foreach ($_POST as $key => $value) {
                        if (strpos($key, "modifyCnp_") === 0) {
                            $modifyCnp = substr($key, strlen("modifyCnp_"));
                            $newName = $_POST["newName_$modifyCnp"];
                            $newSurname = $_POST["newSurname_$modifyCnp"];
                            $modifySql = "UPDATE angajati SET nume = '$newName', prenume = '$newSurname' WHERE cnp = $modifyCnp";
                            mysqli_query($connection, $modifySql);
                        }
                    }
                }

                // Read all rows from the database table
                $sql = "SELECT * FROM angajati";
                $result = mysqli_query($connection, $sql);

                if (!$result) {
                    die("Invalid query");
                }

                // Read data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "
                    <tr>
                        <td>".$row['cnp']."</td>   
                        <td>".$row['nume']."</td>  
                        <td>".$row['prenume']."</td>
                        <td>".$row['id_servicef']."</td>
                        <td>
                            <form method='POST' action='".$_SERVER["PHP_SELF"]."'>
                                <input type='hidden' name='deleteCnp' value='".$row['cnp']."'>
                                <button type='submit' class='btn btn-danger'>Delete</button>
                            </form>
                            <form method='POST' action='".$_SERVER["PHP_SELF"]."'>
                                <input type='hidden' name='modifyCnp_".$row['cnp']."' value='".$row['cnp']."'>
                                <input type='text' name='newName_".$row['cnp']."' placeholder='New Name'>
                                <input type='text' name='newSurname_".$row['cnp']."' placeholder='New Surname'>
                                <button type='submit' class='btn btn-primary'>Modify</button>
                            </form>
                        </td>
                    </tr>  
                    ";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
