<?php //include('functions.php') 
if (!isset($_SESSION)) {
	session_start();
	}
require_once "conn.php";
if(isset($_POST['login_btn'])){
    $username = $_POST['username'];
    $parola = $_POST['password'];
    if(empty($username) || empty($password)){
        $message[] = "Nu ai completat toate campurile";
    }
    $sql = "SELECT * from `conturi` WHERE `adresa_email`= '".$username."'";
    if($result = mysqli_query($conn, $sql)){
		if(mysqli_num_rows($result) > 0){
		    while($row = mysqli_fetch_array($result)){
		        $username_db = $row['adresa_email'];
				$parola_db = $row['parola'];
				$id_sesiune = $row['id_cont']; 
				$is_admin = $row['rol'];
                
		    }
		    mysqli_free_result($result);
		} else{
            ?>
            <script>
            alert("Datele introduse sunt incorecte");
            window.location.replace("./login.php");
            </script>
            <?php
		}
	} else{
		echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
	}
    if($parola == $parola_db){
        ?> 
        <script>
            alert("Bine ai venit,<?php echo $username; ?> !");
            
        </script>
        
        <?php
        session_start();
        $_SESSION["user"] = $id_sesiune;
        $_SESSION["adresa_email"] = $username;
        if ($is_admin== 'admin') 
        {
        ?> 
        <script>
            window.location.replace("./admin.php");
        </script>
        <?php
        }
        ?> 
        <script>

            window.location.replace("./index.php");
        </script>
        <?php
    }else{
        ?> 
        <script>
            alert("Datele introduse sunt incorecte");
        </script>
        <?php
    }
    
}

                
    

?>
<!DOCTYPE html>
<html>
<head>
 <title>Register for user</title>
 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
<style>
body {
  background-image: url('imagini/audi.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 90% 100%;
  background-position: center;
}
</style>
 <div class="header">
  <h2>Login</h2>
 </div>
 
 <form method="post" action="#">

  <?php //echo display_error(); ?>

  <div class="input-group">
   <label>E-mail</label>
   <input type="text" name="username" >
  </div>
  <div class="input-group">
   <label>Password</label>
   <input type="password" name="password">
  </div>
  <div class="input-group">
   <button type="submit" class="btn" name="login_btn">Login</button>
  </div>
  <p>
   Not yet a member? <a href="register.php">Sign up</a>
  </p>
 </form>


</body>
</html>