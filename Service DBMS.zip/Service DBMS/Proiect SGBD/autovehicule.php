<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e90ff;
            color: #fff;
        }

        .container {
            max-width: 1200px;
        }

        .my-5 {
            margin-top: 3rem;
            margin-bottom: 3rem;
        }

        table {
            width: 100%;
            max-width: 1000px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            color: #000; /* Culoarea textului pentru tabel */
        }

        table th,
        table td {
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container my-5">
    <h1><center>AUTOVEHICULE</center></h1><br>
        <table>
            <thead>
                <tr>
                    <th>vin</th>
                    <th>kilometraj</th>
                    <th>capacitate_motor</th>
                    <th>tip_combustibil</th>
                    <th>an_fabricatie</th>
                    <th>marci_id_marci</th>
                    <th>id_clientf</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "service_auto_sgbd";

                // Create connection
                $connection = mysqli_connect($servername, $username, $password, $database);

                // Check connection
                if (!$connection) {
                    die("Connection failed");
                }

                // Read all rows from the database table
                $sql = "SELECT * FROM autovehicule";
                $result = mysqli_query($connection, $sql);

                if (!$result) {
                    die("Invalid query");
                }

                // Read data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "
                    <tr>
                        <td>$row[vin]</td>   
                        <td>$row[kilometraj]</td>  
                        <td>$row[capacitate_motor]</td>
                        <td>$row[tip_combustibil]</td>
                        <td>$row[an_fabricatie]</td>
                        <td>$row[marci_id_marci]</td>
                        <td>$row[id_clientf]</td>
                    </tr>  
                    ";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
