document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    const menuItems = Array.from(document.querySelectorAll('.menu-item:not(.search)'));

    searchForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const searchTerm = searchInput.value.toLowerCase();
        menuItems.forEach(function(item) {
            const menuItemText = item.innerText.toLowerCase();
            if (menuItemText.includes(searchTerm)) {
                item.style.display = 'block';
                item.classList.add('highlighted');
            } else {
                item.style.display = 'none';
                item.classList.remove('highlighted');
            }
        });
    });
});
