<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e90ff;
            color: #fff;
        }

        .container {
            max-width: 800px;
        }

        .my-5 {
            margin-top: 3rem;
            margin-bottom: 3rem;
            
        }

        .table {
            background-color: #fff;
            border-radius: 8px;
            color: #000; /* Culoarea textului pentru tabel */
            margin: 0 auto;
        }

        .table th,
        .table td {
            padding: 10px;
        }
    </style>
</head>
<body>
<a class="btn btn-secondary" href="index.php" role="button">BACK</a>

    <div class="container my-5">
        <h1><center>PROIECTIE</center></h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th>id_operatie</th>
                    <th>data_start</th>
                    <th>cost</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "service_auto_sgbd";

                // Create connection
                $connection = mysqli_connect($servername, $username, $password, $database);

                // Check connection
                if (!$connection) {
                    die("Connection failed");
                }

                // Read all rows from the database table
                $sql = "SELECT id_operatie, data_start, cost
                FROM operatii where cost='1600 lei';";
                $result = mysqli_query($connection, $sql);

                if (!$result) {
                    die("Invalid query");
                }

                // Read data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "
                    <tr>
                        <td>$row[id_operatie]</td>  
                        <td>$row[data_start]</td>  
                        <td>$row[cost]</td>  
                    </tr>  
                    ";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
