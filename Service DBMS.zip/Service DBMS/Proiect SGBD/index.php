<?php 
 include('functions.php');

 if (!isLoggedIn()) {
  $_SESSION['msg'] = "You must log in first";
  header('location: login.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGBD</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
</head>
<body>
    <nav class="navbar">
        <ul class="menu">
            <li class="menu-item">
                <a href="#">Tabele</a>
                <ul class="submenu">
                    <li><a href="marci.php">MARCI</a></li>
                    <li><a href="modele.php">MODELE</a></li>
                    <li><a href="autovehicule.php">AUTOVEHICULE</a></li>
                    <li><a href="clienti.php">CLIENTI</a></li>
                    <li><a href="programari.php">PROGRAMARI</a></li>
                    <li><a href="service-uri.php">SERVICE-URI</a></li>
                    <li><a href="adrese.php">ADRESE</a></li>
                    <li><a href="furnizori.php">FURNIZORI</a></li>
                    <li><a href="piese.php">PIESE</a></li>
                    <li><a href="operatii.php">OPERATI</a></li>
                    <li><a href="angajati.php">ANGAJATI</a></li>
                    <li><a href="job-uri.php">JOB-URI</a></li>
                    <li><a href="transe_de_vechime.php">TRANSE DE VECHIME</a></li>
                    <li><a href="itp-uri.php">ITP-URI</a></li>
                    <li><a href="reparatii_mecanice.php">REPARATII MECANICE</a></li>
                    <li><a href="reparatii_electrice.php">REPARATII ELECTRICE</a></li>
                    <li><a href="piese_defecte.php">PIESE DEFECTE</a></li>
                    <li><a href="erori.php">ERORI</a></li>
                    <li><a href="mecanici.php">MECANICI</a></li>
                    <li><a href="electricieni.php">ELECTRICIENI</a></li>
                    <li><a href="coordonate.php">COORDONATE</a></li>
                </ul>
            </li>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <li class="menu-item">
                <a href="#">Operatii</a>
                <ul class="submenu">
                    <li><a href="reuniune.php">Operatie1</a></li>
                    <li><a href="diferenta.php">Operatie2</a></li>
                    <li><a href="proiectie.php">Operatie3</a></li>
                    <li><a href="jonctiune1.php">Operatie4</a></li>
                    <li><a href="jonctiune2.php">Operatie5</a></li>
                    <li><a href="selectie.php">Operatie6</a></li>
                </ul>
            </li>
            <li class="menu-item search">
                <form id="search-form">
                    <input type="text" id="search-input" placeholder="Caută...">
                    <button type="submit">Caută</button>
                </form>
            </li>
        </ul>
    </nav>

    <script src="script.js"></script>
</body>
</html>
