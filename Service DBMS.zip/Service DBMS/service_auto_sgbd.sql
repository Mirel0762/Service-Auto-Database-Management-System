-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 13, 2023 at 09:42 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `service_auto_sgbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `adrese`
--

DROP TABLE IF EXISTS `adrese`;
CREATE TABLE IF NOT EXISTS `adrese` (
  `id_adresa` varchar(50) NOT NULL,
  `numar` int(11) NOT NULL,
  `strada` varchar(40) NOT NULL,
  `localitate` varchar(40) NOT NULL,
  `judet` varchar(40) NOT NULL,
  PRIMARY KEY (`id_adresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adrese`
--

INSERT INTO `adrese` (`id_adresa`, `numar`, `strada`, `localitate`, `judet`) VALUES
('1', 56, 'Randunici', 'Poiana', 'DJ'),
('2', 98, 'Copacului', 'Varbilau', 'HD'),
('3', 43, 'Mihai Bravu', 'Tinosu', 'AG'),
('4', 23, 'Portocalilor', 'Ploiesti', 'PH'),
('5', 39, 'Undelor', 'Banesti', 'B'),
('6', 39, 'Craiului', 'Mogosoiu', 'MM'),
('7', 104, 'Cireselor', 'Mangalia', 'CT');

-- --------------------------------------------------------

--
-- Table structure for table `angajati`
--

DROP TABLE IF EXISTS `angajati`;
CREATE TABLE IF NOT EXISTS `angajati` (
  `cnp` int(11) NOT NULL,
  `nume` varchar(50) NOT NULL,
  `prenume` varchar(50) NOT NULL,
  `id_servicef` varchar(20) NOT NULL,
  PRIMARY KEY (`cnp`),
  KEY `id_servicef` (`id_servicef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `angajati`
--

INSERT INTO `angajati` (`cnp`, `nume`, `prenume`, `id_servicef`) VALUES
(1234567890, 'Radu', 'Tiberiu', 'A1234B567C890D'),
(1234567891, 'Voicu', 'Alexandru', 'Q1357R864S210T'),
(1345678901, 'Marga', 'Robert', 'U7890V123W456X'),
(1456789123, 'Georgescu', 'Alexandu', 'E9876F543G210H'),
(1678901234, 'Gheorghe', 'Ionut', 'Y0123Z456A789B'),
(1789012345, 'Paraschiv', 'Ionut', 'I5432J109K876L'),
(1901234567, 'Dumitrescu', 'Oana', 'M2468N135O579P');

-- --------------------------------------------------------

--
-- Table structure for table `angajati_has_joburi`
--

DROP TABLE IF EXISTS `angajati_has_joburi`;
CREATE TABLE IF NOT EXISTS `angajati_has_joburi` (
  `angajat_id_angajatf` int(11) NOT NULL,
  `job_id_job` int(11) NOT NULL,
  PRIMARY KEY (`angajat_id_angajatf`,`job_id_job`),
  KEY `angajat_id_angajatf` (`angajat_id_angajatf`),
  KEY `job_id_job` (`job_id_job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `angajati_has_joburi`
--

INSERT INTO `angajati_has_joburi` (`angajat_id_angajatf`, `job_id_job`) VALUES
(1345678901, 3),
(1456789123, 4),
(1456789123, 5),
(1678901234, 7),
(1789012345, 6),
(1901234567, 2);

-- --------------------------------------------------------

--
-- Table structure for table `autovehicule`
--

DROP TABLE IF EXISTS `autovehicule`;
CREATE TABLE IF NOT EXISTS `autovehicule` (
  `vin` varchar(15) NOT NULL,
  `kilometraj` varchar(15) NOT NULL,
  `capacitate_motor` varchar(15) NOT NULL,
  `tip_combustibil` varchar(15) NOT NULL,
  `an_fabricatie` int(11) NOT NULL,
  `marci_id_marci` int(11) NOT NULL,
  `id_clientf` int(11) NOT NULL,
  PRIMARY KEY (`vin`),
  KEY `marci_id_marci` (`marci_id_marci`),
  KEY `id_clientf` (`id_clientf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `autovehicule`
--

INSERT INTO `autovehicule` (`vin`, `kilometraj`, `capacitate_motor`, `tip_combustibil`, `an_fabricatie`, `marci_id_marci`, `id_clientf`) VALUES
('AB1C23D4E56789', '88012 km', '3600 cm^3', 'benzina', 1998, 2, 2),
('FG2H45I6J78901', '70120 km', '100 kWh', 'electric', 2022, 3, 3),
('KL3M67N8O90123', '80002km', '6000 cm^3', 'benzina', 2019, 4, 4),
('PQ4R89S0T12345', '280.000 km', '2000 cm^3', 'diesel', 2016, 5, 5),
('UV5W90X1Y23456', ' 334009 km', '1600 cm^3', 'GPL+benzina', 2007, 6, 6),
('ZA6B78C9D01234', '27922 km', '2000 cm^3', 'benzina', 2018, 7, 7),
('ZFAHU23Y7R5123', '13000 km', '4400 cm^3', 'benzina', 2021, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `clienti`
--

DROP TABLE IF EXISTS `clienti`;
CREATE TABLE IF NOT EXISTS `clienti` (
  `id_client` int(11) NOT NULL,
  `nume` varchar(30) NOT NULL,
  `prenume` varchar(30) NOT NULL,
  `nr_telefon` varchar(20) NOT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clienti`
--

INSERT INTO `clienti` (`id_client`, `nume`, `prenume`, `nr_telefon`) VALUES
(1, 'Dumitru', 'Mirel', '0727944533'),
(2, 'Voicu', 'Alexandru', '0723456789'),
(3, 'Temelie', 'Gabriel', '0771234567'),
(4, 'Mihalache', 'Andreea', '0710543210'),
(5, 'Vasilescu', 'Maria', '0766432109'),
(6, 'Olimpius', 'Filip', '0799876543'),
(7, 'Popa', 'Gheorghe', '0710543210');

-- --------------------------------------------------------

--
-- Table structure for table `conturi`
--

DROP TABLE IF EXISTS `conturi`;
CREATE TABLE IF NOT EXISTS `conturi` (
  `rol` varchar(30) NOT NULL,
  `adresa_email` varchar(50) NOT NULL,
  `parola` varchar(50) NOT NULL,
  `nume` varchar(50) NOT NULL,
  `id_cont` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_cont`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `conturi`
--

INSERT INTO `conturi` (`rol`, `adresa_email`, `parola`, `nume`, `id_cont`) VALUES
('admin', 'dumitrumirel411@gmail.com', 'parolaadmin', '', 1),
('user', 'contusert01@gmail.com', 'cont01', '', 2),
('user', 'gg@yahoo.com', 'parola', '1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `coordonate`
--

DROP TABLE IF EXISTS `coordonate`;
CREATE TABLE IF NOT EXISTS `coordonate` (
  `id_coordonata` varchar(100) NOT NULL,
  `coordonata_x` varchar(100) NOT NULL,
  `coordonata_y` varchar(100) NOT NULL,
  PRIMARY KEY (`id_coordonata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coordonate`
--

INSERT INTO `coordonate` (`id_coordonata`, `coordonata_x`, `coordonata_y`) VALUES
('1', '44.28182267240857', '23.779060378611614'),
('2', '44.358868106325936', '26.084099651551586'),
('3', '44.28182267240857', '23.779060378611614'),
('4', '44.93798107775821', '26.002390973673588'),
('5', '45.67122928384701', '25.58702079504031'),
('6', '45.76310287588881', '22.89958100614512'),
('7', '47.74863176854693', '23.906866541314233');

-- --------------------------------------------------------

--
-- Table structure for table `electricieni`
--

DROP TABLE IF EXISTS `electricieni`;
CREATE TABLE IF NOT EXISTS `electricieni` (
  `cod_electrician` int(11) NOT NULL,
  `program_diagnostic` varchar(30) NOT NULL,
  PRIMARY KEY (`cod_electrician`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `electricieni`
--

INSERT INTO `electricieni` (`cod_electrician`, `program_diagnostic`) VALUES
(1234567890, 'AutoScan Pro'),
(1234567891, 'DiagnosticMaster'),
(1345678901, 'CarTech Analyzer'),
(1456789123, 'AutoCheck Plus'),
(1678901234, 'VehicleScan Elite'),
(1789012345, 'DiagnoPro'),
(1901234567, 'AutoDiagnostics Xpert');

-- --------------------------------------------------------

--
-- Table structure for table `erori`
--

DROP TABLE IF EXISTS `erori`;
CREATE TABLE IF NOT EXISTS `erori` (
  `id_eroare` int(11) NOT NULL,
  `denumire` varchar(20) NOT NULL,
  `prioritate` varchar(20) NOT NULL,
  `electric_id_electric` int(11) NOT NULL,
  PRIMARY KEY (`id_eroare`),
  KEY `electric_id_electric` (`electric_id_electric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `erori`
--

INSERT INTO `erori` (`id_eroare`, `denumire`, `prioritate`, `electric_id_electric`) VALUES
(1, 'aprindere a bujiei', 'ridicata', 1),
(2, ' catalizatorul-', 'medie', 2),
(3, 'amestec sarac', 'coborata', 3),
(4, 'Controlul ralant', 'II', 4),
(5, 'Senzorul de debit', 'III', 5),
(6, 'Circuitul alimentare', 'IV', 6),
(7, 'convertorul cuplu', 'I', 7);

-- --------------------------------------------------------

--
-- Table structure for table `furnizori`
--

DROP TABLE IF EXISTS `furnizori`;
CREATE TABLE IF NOT EXISTS `furnizori` (
  `cui` int(20) NOT NULL,
  `nume` varchar(50) NOT NULL,
  PRIMARY KEY (`cui`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `furnizori`
--

INSERT INTO `furnizori` (`cui`, `nume`) VALUES
(123456789, 'CarTech Solutions'),
(134567890, 'AutoPro Supply'),
(145678912, 'Autoparts Direct'),
(167890123, 'Precision Auto Components'),
(178901235, 'Speedy Auto Parts'),
(189012345, 'Global Parts Network'),
(190123457, 'MotoParts Supplier');

-- --------------------------------------------------------

--
-- Table structure for table `furnizori_has_piese`
--

DROP TABLE IF EXISTS `furnizori_has_piese`;
CREATE TABLE IF NOT EXISTS `furnizori_has_piese` (
  `furnizori_id_furnizori` int(11) NOT NULL,
  `piese_id_piese` int(11) NOT NULL,
  PRIMARY KEY (`furnizori_id_furnizori`,`piese_id_piese`),
  KEY `furnizori_id_furnizori` (`furnizori_id_furnizori`),
  KEY `piese_id_piese` (`piese_id_piese`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `furnizori_has_piese`
--

INSERT INTO `furnizori_has_piese` (`furnizori_id_furnizori`, `piese_id_piese`) VALUES
(123456789, 1),
(134567890, 2),
(145678912, 3),
(167890123, 4),
(178901235, 5),
(189012345, 6),
(190123457, 7);

-- --------------------------------------------------------

--
-- Table structure for table `itpuri`
--

DROP TABLE IF EXISTS `itpuri`;
CREATE TABLE IF NOT EXISTS `itpuri` (
  `cod_itp` int(11) NOT NULL,
  `rezultat` varchar(20) NOT NULL,
  `data_expirare` date NOT NULL,
  PRIMARY KEY (`cod_itp`),
  KEY `cod_itp` (`cod_itp`),
  KEY `cod_itp_2` (`cod_itp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `itpuri`
--

INSERT INTO `itpuri` (`cod_itp`, `rezultat`, `data_expirare`) VALUES
(1, 'admis', '2024-02-15'),
(2, 'ok', '2023-05-18'),
(3, 'excelent', '2025-04-09'),
(4, 'admis', '2024-02-15'),
(5, 'admis', '2024-02-15'),
(6, 'reprogramat', '2025-04-24'),
(7, 'ok', '2024-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `joburi`
--

DROP TABLE IF EXISTS `joburi`;
CREATE TABLE IF NOT EXISTS `joburi` (
  `id_job` int(11) NOT NULL,
  `titlu` varchar(30) NOT NULL,
  PRIMARY KEY (`id_job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `joburi`
--

INSERT INTO `joburi` (`id_job`, `titlu`) VALUES
(1, 'Contabil'),
(2, 'Manager'),
(3, 'Vulcanizator'),
(4, 'Mecanic'),
(5, 'Electrician'),
(6, 'Paznic'),
(7, 'Tester');

-- --------------------------------------------------------

--
-- Table structure for table `marci`
--

DROP TABLE IF EXISTS `marci`;
CREATE TABLE IF NOT EXISTS `marci` (
  `cod_marca` int(11) NOT NULL,
  `denumire` varchar(50) NOT NULL,
  PRIMARY KEY (`cod_marca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marci`
--

INSERT INTO `marci` (`cod_marca`, `denumire`) VALUES
(1, 'BMW'),
(2, 'Toyota'),
(3, 'Tesla'),
(4, 'Mercedes'),
(5, 'Skoda'),
(6, 'Citroen'),
(7, 'Alfa Romeo');

-- --------------------------------------------------------

--
-- Table structure for table `mecanici`
--

DROP TABLE IF EXISTS `mecanici`;
CREATE TABLE IF NOT EXISTS `mecanici` (
  `cod_mecanic` int(11) NOT NULL,
  `marca_cunoscuta` varchar(30) NOT NULL,
  PRIMARY KEY (`cod_mecanic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mecanici`
--

INSERT INTO `mecanici` (`cod_mecanic`, `marca_cunoscuta`) VALUES
(1234567890, 'Volkswagen'),
(1234567891, 'BMW'),
(1345678901, 'Audi'),
(1456789123, 'Tesla'),
(1678901234, 'Alfa Roneo'),
(1789012345, 'Citroen'),
(1901234567, 'Ford');

-- --------------------------------------------------------

--
-- Table structure for table `modele`
--

DROP TABLE IF EXISTS `modele`;
CREATE TABLE IF NOT EXISTS `modele` (
  `cod_model` int(11) NOT NULL,
  `denumire` varchar(25) NOT NULL,
  `id_marcif` int(11) NOT NULL,
  PRIMARY KEY (`cod_model`),
  KEY `id_marcif` (`id_marcif`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `modele`
--

INSERT INTO `modele` (`cod_model`, `denumire`, `id_marcif`) VALUES
(1, 'M5 Competiton', 1),
(2, 'Supra', 2),
(3, 'Plaid', 3),
(4, 'Maybach', 4),
(5, 'Rapid', 5),
(6, 'C5', 6),
(7, 'Giulia', 7);

-- --------------------------------------------------------

--
-- Table structure for table `operatii`
--

DROP TABLE IF EXISTS `operatii`;
CREATE TABLE IF NOT EXISTS `operatii` (
  `id_operatie` int(11) NOT NULL,
  `data_start` date NOT NULL,
  `data_finalizare` date NOT NULL,
  `timp_necesar` varchar(15) NOT NULL,
  `cost` varchar(15) NOT NULL,
  `id_programaref` int(11) NOT NULL,
  PRIMARY KEY (`id_operatie`),
  KEY `id_programaref` (`id_programaref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operatii`
--

INSERT INTO `operatii` (`id_operatie`, `data_start`, `data_finalizare`, `timp_necesar`, `cost`, `id_programaref`) VALUES
(1, '2023-06-08', '2023-06-09', '24 h', '1600 lei', 1),
(2, '2023-06-07', '2023-06-13', '10 h', '1200 lei', 2),
(3, '2023-05-03', '2023-05-10', '36 h', '2000 lei', 3),
(4, '2023-05-16', '2023-06-16', '1 h', '150 lei', 4),
(5, '2023-05-10', '2023-05-12', '14 h', '1150 lei', 5),
(6, '2023-05-16', '2023-05-18', '20h', '2300 lei', 6),
(7, '2023-06-08', '2023-06-11', '30 h', '4000 lei', 7);

-- --------------------------------------------------------

--
-- Table structure for table `operatii_has_angajati`
--

DROP TABLE IF EXISTS `operatii_has_angajati`;
CREATE TABLE IF NOT EXISTS `operatii_has_angajati` (
  `operatie_id_operatie` int(11) NOT NULL,
  `angajat_id_angajat` int(11) NOT NULL,
  PRIMARY KEY (`operatie_id_operatie`,`angajat_id_angajat`),
  KEY `operatie_id_operatie` (`operatie_id_operatie`),
  KEY `angajat_id_angajat` (`angajat_id_angajat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operatii_has_angajati`
--

INSERT INTO `operatii_has_angajati` (`operatie_id_operatie`, `angajat_id_angajat`) VALUES
(1, 1234567890),
(2, 1234567891),
(3, 1345678901),
(4, 1456789123),
(5, 1678901234),
(6, 1789012345),
(7, 1901234567);

-- --------------------------------------------------------

--
-- Table structure for table `piese`
--

DROP TABLE IF EXISTS `piese`;
CREATE TABLE IF NOT EXISTS `piese` (
  `cod_piesa` int(11) NOT NULL,
  `tip` varchar(30) NOT NULL,
  `denumire` varchar(50) NOT NULL,
  `valabilitate` varchar(20) NOT NULL,
  `pret` varchar(20) NOT NULL,
  `id_operatief` int(11) NOT NULL,
  PRIMARY KEY (`cod_piesa`),
  KEY `id_operatief` (`id_operatief`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `piese`
--

INSERT INTO `piese` (`cod_piesa`, `tip`, `denumire`, `valabilitate`, `pret`, `id_operatief`) VALUES
(1, 'sistem electric', 'Baterie', '2 ani', '400 lei', 1),
(2, 'sistem de incarcare', 'Alternator', '3 ani', '700', 2),
(3, 'Pompa de combustibil', 'sistem de alimentare', '2 ani', '850 lei', 3),
(4, 'sistem de franare', 'Frane', '5 ani', '550 lei', 4),
(5, 'sistem de racire', 'Radiator', '3 ani', '780 lei', 5),
(6, ' sistem de transmisie', 'Ambreaj', '4 ani', '1000 lei', 6),
(7, 'sistem de pornire', 'Motor de pornire', '3 ani', '1500 lei', 7);

-- --------------------------------------------------------

--
-- Table structure for table `piese_defecte`
--

DROP TABLE IF EXISTS `piese_defecte`;
CREATE TABLE IF NOT EXISTS `piese_defecte` (
  `id_piesa` int(11) NOT NULL,
  `denumire` varchar(30) NOT NULL,
  `mecanica_id_mecanica` int(11) NOT NULL,
  PRIMARY KEY (`id_piesa`),
  KEY `mecanica_id_mecanica` (`mecanica_id_mecanica`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `piese_defecte`
--

INSERT INTO `piese_defecte` (`id_piesa`, `denumire`, `mecanica_id_mecanica`) VALUES
(1, 'Bobina de aprindere', 1),
(2, 'Senzor de oxigen', 2),
(3, 'Senzor de temperatura', 3),
(4, 'Pompele de apa și ulei', 4),
(5, 'Radiatorul de incalzire', 5),
(6, 'Ventilatorul de racire', 6),
(7, 'EGR', 7);

-- --------------------------------------------------------

--
-- Table structure for table `programari`
--

DROP TABLE IF EXISTS `programari`;
CREATE TABLE IF NOT EXISTS `programari` (
  `cod_programare` int(11) NOT NULL,
  `ora` time NOT NULL,
  `data` date NOT NULL,
  `clienti_id_clienti` int(11) NOT NULL,
  `service_cui` varchar(30) NOT NULL,
  PRIMARY KEY (`cod_programare`),
  KEY `clienti_id_clienti` (`clienti_id_clienti`),
  KEY `service_cui` (`service_cui`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programari`
--

INSERT INTO `programari` (`cod_programare`, `ora`, `data`, `clienti_id_clienti`, `service_cui`) VALUES
(1, '14:55:00', '2023-04-13', 1, 'A1234B567C890D'),
(2, '13:56:00', '2023-05-30', 2, 'E9876F543G210H'),
(3, '09:00:00', '2023-05-16', 3, 'I5432J109K876L'),
(4, '10:30:00', '2023-04-13', 4, 'M2468N135O579P'),
(5, '12:00:00', '2023-06-06', 5, 'Q1357R864S210T'),
(6, '12:30:00', '2023-03-22', 6, 'U7890V123W456X'),
(7, '11:30:00', '2023-06-01', 7, 'Y0123Z456A789B');

-- --------------------------------------------------------

--
-- Table structure for table `re`
--

DROP TABLE IF EXISTS `re`;
CREATE TABLE IF NOT EXISTS `re` (
  `cod_reparatiee` int(11) NOT NULL,
  `cod_eroare` varchar(20) NOT NULL,
  PRIMARY KEY (`cod_reparatiee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `re`
--

INSERT INTO `re` (`cod_reparatiee`, `cod_eroare`) VALUES
(1, '101'),
(2, '102'),
(3, '103'),
(4, '104'),
(5, '105'),
(6, '106'),
(7, '107');

-- --------------------------------------------------------

--
-- Table structure for table `rm`
--

DROP TABLE IF EXISTS `rm`;
CREATE TABLE IF NOT EXISTS `rm` (
  `cod_reparatiem` int(11) NOT NULL,
  `cod_eroare` varchar(20) NOT NULL,
  PRIMARY KEY (`cod_reparatiem`),
  KEY `cod_reparatiem` (`cod_reparatiem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rm`
--

INSERT INTO `rm` (`cod_reparatiem`, `cod_eroare`) VALUES
(1, '201'),
(2, '202'),
(3, '203'),
(4, '204'),
(5, '205'),
(6, '206'),
(7, '207');

-- --------------------------------------------------------

--
-- Table structure for table `serviceuri`
--

DROP TABLE IF EXISTS `serviceuri`;
CREATE TABLE IF NOT EXISTS `serviceuri` (
  `cui` varchar(30) NOT NULL,
  `nume` varchar(50) NOT NULL,
  `program_lucru` varchar(50) NOT NULL,
  `nr_telefon` varchar(20) NOT NULL,
  `id_adresef` varchar(100) NOT NULL,
  PRIMARY KEY (`cui`),
  KEY `id_adresef` (`id_adresef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `serviceuri`
--

INSERT INTO `serviceuri` (`cui`, `nume`, `program_lucru`, `nr_telefon`, `id_adresef`) VALUES
('A1234B567C890D', 'EKA TRUST', '08:00-16:00', '0702 345 678', '1'),
('E9876F543G210H', 'Inligence Repair', '07:30-15:00', '0719 012 345', '3'),
('I5432J109K876L', 'Elite Service', '09:00-16:30', '0768 901 234', '4'),
('M2468N135O579P', 'Grafix', '09:30-17:00', '0775 432 109', '2'),
('Q1357R864S210T', 'Flux Car', '08:00-17:10', '0723 456 789', '5'),
('U7890V123W456X', 'Md Motors', '11:00-19:00', '0791 234 567', '6'),
('Y0123Z456A789B', 'Hd Autotest', '07:00:16-45', '0740 567 890', '7');

-- --------------------------------------------------------

--
-- Table structure for table `transe_de_vechime`
--

DROP TABLE IF EXISTS `transe_de_vechime`;
CREATE TABLE IF NOT EXISTS `transe_de_vechime` (
  `cod_transa` int(11) NOT NULL,
  `categorie` varchar(15) NOT NULL,
  `salariu` varchar(15) NOT NULL,
  PRIMARY KEY (`cod_transa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transe_de_vechime`
--

INSERT INTO `transe_de_vechime` (`cod_transa`, `categorie`, `salariu`) VALUES
(1234567890, 'I', '2000 lei'),
(1234567891, 'II', '2500 lei'),
(1345678901, 'III', '2700 lei'),
(1456789123, 'IV', '4000 lei'),
(1678901234, 'I', '1800 lei'),
(1789012345, 'III', '3600 lei'),
(1901234567, 'II', '5000 lei');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `angajati`
--
ALTER TABLE `angajati`
  ADD CONSTRAINT `angajati_ibfk_1` FOREIGN KEY (`id_servicef`) REFERENCES `serviceuri` (`cui`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `angajati_has_joburi`
--
ALTER TABLE `angajati_has_joburi`
  ADD CONSTRAINT `angajati_has_joburi_ibfk_1` FOREIGN KEY (`angajat_id_angajatf`) REFERENCES `angajati` (`cnp`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `angajati_has_joburi_ibfk_2` FOREIGN KEY (`job_id_job`) REFERENCES `joburi` (`id_job`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `autovehicule`
--
ALTER TABLE `autovehicule`
  ADD CONSTRAINT `autovehicule_ibfk_1` FOREIGN KEY (`marci_id_marci`) REFERENCES `marci` (`cod_marca`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `autovehicule_ibfk_2` FOREIGN KEY (`id_clientf`) REFERENCES `clienti` (`id_client`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `conturi`
--
ALTER TABLE `conturi`
  ADD CONSTRAINT `conturi_ibfk_1` FOREIGN KEY (`id_cont`) REFERENCES `clienti` (`id_client`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `coordonate`
--
ALTER TABLE `coordonate`
  ADD CONSTRAINT `coordonate_ibfk_1` FOREIGN KEY (`id_coordonata`) REFERENCES `adrese` (`id_adresa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `electricieni`
--
ALTER TABLE `electricieni`
  ADD CONSTRAINT `electricieni_ibfk_1` FOREIGN KEY (`cod_electrician`) REFERENCES `angajati` (`cnp`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `erori`
--
ALTER TABLE `erori`
  ADD CONSTRAINT `erori_ibfk_1` FOREIGN KEY (`electric_id_electric`) REFERENCES `re` (`cod_reparatiee`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `furnizori_has_piese`
--
ALTER TABLE `furnizori_has_piese`
  ADD CONSTRAINT `furnizori_has_piese_ibfk_1` FOREIGN KEY (`furnizori_id_furnizori`) REFERENCES `furnizori` (`cui`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `furnizori_has_piese_ibfk_2` FOREIGN KEY (`piese_id_piese`) REFERENCES `piese` (`cod_piesa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `itpuri`
--
ALTER TABLE `itpuri`
  ADD CONSTRAINT `itpuri_ibfk_1` FOREIGN KEY (`cod_itp`) REFERENCES `operatii` (`id_operatie`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mecanici`
--
ALTER TABLE `mecanici`
  ADD CONSTRAINT `mecanici_ibfk_1` FOREIGN KEY (`cod_mecanic`) REFERENCES `angajati` (`cnp`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modele`
--
ALTER TABLE `modele`
  ADD CONSTRAINT `modele_ibfk_1` FOREIGN KEY (`id_marcif`) REFERENCES `marci` (`cod_marca`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `operatii`
--
ALTER TABLE `operatii`
  ADD CONSTRAINT `operatii_ibfk_1` FOREIGN KEY (`id_programaref`) REFERENCES `programari` (`cod_programare`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `operatii_has_angajati`
--
ALTER TABLE `operatii_has_angajati`
  ADD CONSTRAINT `operatii_has_angajati_ibfk_1` FOREIGN KEY (`operatie_id_operatie`) REFERENCES `operatii` (`id_operatie`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `operatii_has_angajati_ibfk_2` FOREIGN KEY (`angajat_id_angajat`) REFERENCES `angajati` (`cnp`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `piese`
--
ALTER TABLE `piese`
  ADD CONSTRAINT `piese_ibfk_1` FOREIGN KEY (`id_operatief`) REFERENCES `operatii` (`id_operatie`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `piese_defecte`
--
ALTER TABLE `piese_defecte`
  ADD CONSTRAINT `piese_defecte_ibfk_1` FOREIGN KEY (`mecanica_id_mecanica`) REFERENCES `rm` (`cod_reparatiem`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `programari`
--
ALTER TABLE `programari`
  ADD CONSTRAINT `programari_ibfk_1` FOREIGN KEY (`clienti_id_clienti`) REFERENCES `clienti` (`id_client`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `programari_ibfk_2` FOREIGN KEY (`service_cui`) REFERENCES `serviceuri` (`cui`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `re`
--
ALTER TABLE `re`
  ADD CONSTRAINT `re_ibfk_1` FOREIGN KEY (`cod_reparatiee`) REFERENCES `operatii` (`id_operatie`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rm`
--
ALTER TABLE `rm`
  ADD CONSTRAINT `rm_ibfk_1` FOREIGN KEY (`cod_reparatiem`) REFERENCES `operatii` (`id_operatie`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `serviceuri`
--
ALTER TABLE `serviceuri`
  ADD CONSTRAINT `serviceuri_ibfk_1` FOREIGN KEY (`id_adresef`) REFERENCES `adrese` (`id_adresa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transe_de_vechime`
--
ALTER TABLE `transe_de_vechime`
  ADD CONSTRAINT `transe_de_vechime_ibfk_1` FOREIGN KEY (`cod_transa`) REFERENCES `angajati` (`cnp`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
